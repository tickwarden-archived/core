execute if score #phase vfEf98a9615fe matches 1 run tellraw @a {"text": "[VortaForge EOL] core-7dc59306347b: warning phase; read-only after 72 online hours, locked after 168 online hours at 20 TPS.", "color": "gold"}
execute if score #phase vfEf98a9615fe matches 2 run tellraw @a {"text": "[VortaForge EOL] core-7dc59306347b: restricted functions phase; non-function data and external commands are not blocked. Persistent world data is NOT erased.", "color": "gold"}
execute if score #phase vfEf98a9615fe matches 3 run tellraw @a {"text": "[VortaForge EOL] core-7dc59306347b: EOL locked. Use function vf_eol_f98a9615fe:status for lifecycle state.", "color": "gold"}
scoreboard players operation #last vfEf98a9615fe = #phase vfEf98a9615fe
