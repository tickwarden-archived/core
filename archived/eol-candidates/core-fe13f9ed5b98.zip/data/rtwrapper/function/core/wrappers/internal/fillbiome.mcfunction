# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_95ed379a2f:lifecycle {phase:1} run return 0
# RTWrapper generated named-parameter dispatcher for /fillbiome.
# Provide contiguous parameters in this order:
# from_pos, to_pos, biome, replace, filter
scoreboard players set #pc rtw.status 0
execute if data storage rtwrapper:runtime current.params.from_pos run scoreboard players set #pc rtw.status 1
execute if data storage rtwrapper:runtime current.params.to_pos run scoreboard players set #pc rtw.status 2
execute if data storage rtwrapper:runtime current.params.biome run scoreboard players set #pc rtw.status 3
execute if data storage rtwrapper:runtime current.params.replace run scoreboard players set #pc rtw.status 4
execute if data storage rtwrapper:runtime current.params.filter run scoreboard players set #pc rtw.status 5
execute if score #pc rtw.status matches 0 run function rtwrapper:core/wrappers/internal/variants/fillbiome_0
execute if score #pc rtw.status matches 1 run function rtwrapper:core/wrappers/internal/variants/fillbiome_1 with storage rtwrapper:runtime current.params
execute if score #pc rtw.status matches 2 run function rtwrapper:core/wrappers/internal/variants/fillbiome_2 with storage rtwrapper:runtime current.params
execute if score #pc rtw.status matches 3 run function rtwrapper:core/wrappers/internal/variants/fillbiome_3 with storage rtwrapper:runtime current.params
execute if score #pc rtw.status matches 4 run function rtwrapper:core/wrappers/internal/variants/fillbiome_4 with storage rtwrapper:runtime current.params
execute if score #pc rtw.status matches 5 run function rtwrapper:core/wrappers/internal/variants/fillbiome_5 with storage rtwrapper:runtime current.params
