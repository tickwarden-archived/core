# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_1f44a31786:lifecycle {phase:1} run return 0
# RTWrapper generated named-parameter dispatcher for /me.
# Provide contiguous parameters in this order:
# message
scoreboard players set #pc rtw.status 0
execute if data storage rtwrapper:runtime current.params.message run scoreboard players set #pc rtw.status 1
execute if score #pc rtw.status matches 0 run function rtwrapper:core/wrappers/internal/variants/me_0
execute if score #pc rtw.status matches 1 run function rtwrapper:core/wrappers/internal/variants/me_1 with storage rtwrapper:runtime current.params
