# No automatic schedule clearing: function identifiers may be shared across packs.
# No world, player, storage, objective or entity deletion.
scoreboard players set #cleaned vfEe3996d85f4 1
