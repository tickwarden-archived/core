execute if score #phase vfEe3996d85f4 matches 1 run tellraw @a {"text": "[VortaForge EOL] vorta-core-a09db81f61c1: warning phase; function restrictions after 5184000 ticks and lock after 12096000 ticks (72 and 168 hours only at 20 TPS).", "color": "gold"}
execute if score #phase vfEe3996d85f4 matches 2 run tellraw @a {"text": "[VortaForge EOL] vorta-core-a09db81f61c1: restricted functions phase; non-function data and external commands are not blocked. Persistent world data is NOT erased.", "color": "gold"}
execute if score #phase vfEe3996d85f4 matches 3 run tellraw @a {"text": "[VortaForge EOL] vorta-core-a09db81f61c1: EOL locked. Use function vf_eol_e3996d85f4:status for lifecycle state.", "color": "gold"}
scoreboard players operation #last vfEe3996d85f4 = #phase vfEe3996d85f4
