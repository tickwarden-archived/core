execute if score #phase vfEe3996d85f4 matches 1..2 run scoreboard players add #ticks vfEe3996d85f4 1
function vf_eol_e3996d85f4:refresh
execute unless score #last vfEe3996d85f4 = #phase vfEe3996d85f4 run function vf_eol_e3996d85f4:notice
execute if score #phase vfEe3996d85f4 matches 3 if score #cleaned vfEe3996d85f4 matches 0 run function vf_eol_e3996d85f4:cleanup
