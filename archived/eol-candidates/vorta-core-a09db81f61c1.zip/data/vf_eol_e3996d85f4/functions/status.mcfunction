scoreboard players get #phase vfEe3996d85f4
scoreboard players get #ticks vfEe3996d85f4
scoreboard players get #cleaned vfEe3996d85f4
