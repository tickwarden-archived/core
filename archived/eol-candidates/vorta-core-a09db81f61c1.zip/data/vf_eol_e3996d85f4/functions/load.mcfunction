execute unless data storage vf_eol_e3996d85f4:lifecycle initialized run scoreboard objectives add vfEe3996d85f4 dummy
data modify storage vf_eol_e3996d85f4:lifecycle initialized set value 1b
scoreboard players add #ticks vfEe3996d85f4 0
scoreboard players add #phase vfEe3996d85f4 0
scoreboard players add #last vfEe3996d85f4 0
scoreboard players add #cleaned vfEe3996d85f4 0
function vf_eol_e3996d85f4:refresh
execute unless score #last vfEe3996d85f4 = #phase vfEe3996d85f4 run function vf_eol_e3996d85f4:notice
