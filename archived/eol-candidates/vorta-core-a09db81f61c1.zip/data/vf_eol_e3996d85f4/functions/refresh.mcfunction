scoreboard players set #phase vfEe3996d85f4 1
execute if score #ticks vfEe3996d85f4 matches 5184000.. run scoreboard players set #phase vfEe3996d85f4 2
execute if score #ticks vfEe3996d85f4 matches 12096000.. run scoreboard players set #phase vfEe3996d85f4 3
execute store result storage vf_eol_e3996d85f4:lifecycle phase int 1 run scoreboard players get #phase vfEe3996d85f4
