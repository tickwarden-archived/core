# EOL entry guard; legacy Minecraft requires each command to be gated.
# Run many commands in one pass. Input: storage tunnelscript:in
#   { "commands": [ "say one", "say two" ] }
# Requires the tunnelscript.trusted tag, and requires confirmation
# (ts:gate/yes / ts:gate/cancel) before it actually runs.
execute if data storage vf_eol_e3996d85f4:lifecycle {phase:1} run execute unless entity @s[tag=tunnelscript.trusted] run tellraw @s [{"text":"[TunnelScript] ","color":"aqua"},{"text":"You don't have permission for this action (requires the tunnelscript.trusted tag).","color":"red"}]
execute if data storage vf_eol_e3996d85f4:lifecycle {phase:1} run execute if entity @s[tag=tunnelscript.trusted] run data modify storage tunnelscript_core:gatework req set value {}
execute if data storage vf_eol_e3996d85f4:lifecycle {phase:1} run execute if entity @s[tag=tunnelscript.trusted] run data modify storage tunnelscript_core:gatework req.action set value "run_commands"
execute if data storage vf_eol_e3996d85f4:lifecycle {phase:1} run execute if entity @s[tag=tunnelscript.trusted] run data modify storage tunnelscript_core:gatework req.label set value "run a batch of commands"
execute if data storage vf_eol_e3996d85f4:lifecycle {phase:1} run execute if entity @s[tag=tunnelscript.trusted] run data modify storage tunnelscript_core:gatework req.commands set value {}
execute if data storage vf_eol_e3996d85f4:lifecycle {phase:1} run execute if entity @s[tag=tunnelscript.trusted] run data modify storage tunnelscript_core:gatework req.commands.commands set from storage tunnelscript:in commands
execute if data storage vf_eol_e3996d85f4:lifecycle {phase:1} run execute if entity @s[tag=tunnelscript.trusted] run function tunnelscript_core:internal/gate/request
