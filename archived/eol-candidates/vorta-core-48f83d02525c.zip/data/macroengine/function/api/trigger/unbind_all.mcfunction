# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_9fbc0beb0f:lifecycle {phase:1} run return 0
execute if data storage macroengine:engine modules{trigger:0b} run return 0
data modify storage macroengine:engine trigger_binds set value []