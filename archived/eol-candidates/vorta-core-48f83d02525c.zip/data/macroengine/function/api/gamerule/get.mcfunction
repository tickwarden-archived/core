# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_9fbc0beb0f:lifecycle {phase:1} run return 0
# macroengine:api/gamerule/get [MACRO]
# Reads a custom gamerule value from storage into macroengine:output gamerule.
#
# INPUT (macro args via `with storage macroengine:input {}`):
#   $(rule) — rule name string (must match the name used in set)
#
# OUTPUT:
#   macroengine:output gamerule — the stored value string, or absent if never set
#
# EXAMPLE:
#   data modify storage macroengine:input rule set value "pvp_enabled"
#   function macroengine:api/gamerule/get with storage macroengine:input {}
#   # read: data get storage macroengine:output gamerule


# Normalize key (spaces -> underscores, lowercase). Leaves _gamerule_norm unset when
# the name cannot be normalized safely (contains a quote or a backslash).
execute if data storage macroengine:engine modules{gamerule:0b} run return 0
data remove storage macroengine:input _gamerule_norm
function macroengine:core/internal/api/gamerule/normalize

# Read from engine storage
data remove storage macroengine:output gamerule
function macroengine:core/internal/api/gamerule/read with storage macroengine:input {}

# $(_gamerule_norm) below is a NEW macro invocation's arg, bound at call time
# from current storage — NOT the same binding as this function's own $(rule)
# arg (which was fixed at entry, before _gamerule_norm existed). Calling this
# inline as a bare $tellraw would have silently failed to resolve.
function macroengine:core/internal/api/gamerule/debug_print with storage macroengine:input {}

data remove storage macroengine:input _gamerule_norm
