# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_9fbc0beb0f:lifecycle {phase:1} run return 0
# macroengine:api/block/take
# Takes a stack out of a registered custom block.
#
# INPUT  macroengine:input id (registered block), x, y, z (ints), slot (optional)
# OUTPUT macroengine:output block {ok, denied, item}
# RETURN 1 success, 0 refused / denied / failed. Order: validate handler, then the take handler.
# Handlers run AT the block (execute positioned x y z) and read macroengine:block ctx
# {op, x, y, z, slot?, item?}. A handler returns 1 for success/allow and 0 for failure/deny.
# A handler may write macroengine:output block.item (take / hopper_out).
# End every handler with an explicit `return 1` (allow) or `return 0` (deny).
execute if data storage macroengine:engine modules{block:0b} run return 0
data modify storage macroengine:output block set value {ok:0b,denied:0b}
data modify storage macroengine:block tmp set value {m:{op:"take"}}
execute unless function macroengine:core/internal/api/block/_prepare run return 0
return run function macroengine:core/internal/api/block/_run
