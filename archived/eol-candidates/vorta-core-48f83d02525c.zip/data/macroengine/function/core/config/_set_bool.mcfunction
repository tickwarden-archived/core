# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_9fbc0beb0f:lifecycle {phase:1} run return 0
# macroengine:core/config/_set_bool [MACRO, INTERNAL]  $(key) is a schema key
execute store result score #cfg_in macroengine.tmp run data get storage macroengine:engine config_in.value
$execute if score #cfg_in macroengine.tmp matches ..0 run data modify storage macroengine:engine config.$(key) set value 0b
$execute if score #cfg_in macroengine.tmp matches 1.. run data modify storage macroengine:engine config.$(key) set value 1b
function macroengine:core/config/apply
return 1
