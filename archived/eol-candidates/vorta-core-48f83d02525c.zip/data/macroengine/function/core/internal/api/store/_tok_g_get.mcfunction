# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_9fbc0beb0f:lifecycle {phase:1} run return 0
# macroengine:core/internal/api/store/_tok_g_get [MACRO] [INTERNAL]
$data modify storage macroengine:store tmp.raw set from storage macroengine:store g.$(name)
