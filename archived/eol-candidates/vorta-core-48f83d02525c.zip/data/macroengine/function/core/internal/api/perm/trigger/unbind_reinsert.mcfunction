# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_9fbc0beb0f:lifecycle {phase:1} run return 0
$data modify storage macroengine:engine perm_triggers.$(name) append from storage macroengine:engine _pt_unbind[0]
