# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_9fbc0beb0f:lifecycle {phase:1} run return 0
$data modify storage macroengine:cmd_gate in.cmd set value "$(current_cmd)"
execute unless function macroengine:systems/cmd_gate/check run return 0
$execute run $(current_cmd)
