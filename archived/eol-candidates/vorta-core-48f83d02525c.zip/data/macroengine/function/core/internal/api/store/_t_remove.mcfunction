# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_9fbc0beb0f:lifecycle {phase:1} run return 0
# macroengine:core/internal/api/store/_t_remove [MACRO] [INTERNAL]
$data remove storage macroengine:store tpl.$(name).$(lang)
return 1
