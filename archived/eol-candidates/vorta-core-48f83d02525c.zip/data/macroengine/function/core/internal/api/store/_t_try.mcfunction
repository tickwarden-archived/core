# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_9fbc0beb0f:lifecycle {phase:1} run return 0
# macroengine:core/internal/api/store/_t_try [MACRO] [INTERNAL]
$execute if data storage macroengine:store tpl.$(name).$(lang) run data modify storage macroengine:store tmp.tpl set from storage macroengine:store tpl.$(name).$(lang)
