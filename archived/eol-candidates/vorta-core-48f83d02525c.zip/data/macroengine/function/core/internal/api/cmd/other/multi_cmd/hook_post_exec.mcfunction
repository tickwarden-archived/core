# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_9fbc0beb0f:lifecycle {phase:1} run return 0
# [MACRO] INPUT: $(post_hook)
$function $(post_hook)
