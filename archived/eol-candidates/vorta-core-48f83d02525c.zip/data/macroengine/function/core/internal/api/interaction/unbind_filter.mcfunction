# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_9fbc0beb0f:lifecycle {phase:1} run return 0
execute unless data storage macroengine:engine _ia_ubinds[0] run return 0

data modify storage macroengine:engine _ia_ucur set from storage macroengine:engine _ia_ubinds[0]
data remove storage macroengine:engine _ia_ubinds[0]

function macroengine:core/internal/api/interaction/unbind_check with storage macroengine:engine _ia_ufilter

function macroengine:core/internal/api/interaction/unbind_filter
data remove storage macroengine:engine _ia_ucur
