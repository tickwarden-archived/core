# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_9fbc0beb0f:lifecycle {phase:1} run return 0
# Post-hook runner
function macroengine:core/internal/api/cmd/other/multi_cmd/hook_post_exec with storage macroengine:engine _mcmd_current
