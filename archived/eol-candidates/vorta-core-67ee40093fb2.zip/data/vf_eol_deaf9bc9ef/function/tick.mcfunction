execute if score #phase vfEdeaf9bc9ef matches 1..2 run scoreboard players add #ticks vfEdeaf9bc9ef 1
function vf_eol_deaf9bc9ef:refresh
execute unless score #last vfEdeaf9bc9ef = #phase vfEdeaf9bc9ef run function vf_eol_deaf9bc9ef:notice
execute if score #phase vfEdeaf9bc9ef matches 3 if score #cleaned vfEdeaf9bc9ef matches 0 run function vf_eol_deaf9bc9ef:cleanup
