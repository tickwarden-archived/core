scoreboard players set #phase vfEdeaf9bc9ef 1
execute if score #ticks vfEdeaf9bc9ef matches 5184000.. run scoreboard players set #phase vfEdeaf9bc9ef 2
execute if score #ticks vfEdeaf9bc9ef matches 12096000.. run scoreboard players set #phase vfEdeaf9bc9ef 3
execute store result storage vf_eol_deaf9bc9ef:lifecycle phase int 1 run scoreboard players get #phase vfEdeaf9bc9ef
