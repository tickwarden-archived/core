execute unless data storage vf_eol_deaf9bc9ef:lifecycle initialized run scoreboard objectives add vfEdeaf9bc9ef dummy
data modify storage vf_eol_deaf9bc9ef:lifecycle initialized set value 1b
scoreboard players add #ticks vfEdeaf9bc9ef 0
scoreboard players add #phase vfEdeaf9bc9ef 0
scoreboard players add #last vfEdeaf9bc9ef 0
scoreboard players add #cleaned vfEdeaf9bc9ef 0
function vf_eol_deaf9bc9ef:refresh
execute unless score #last vfEdeaf9bc9ef = #phase vfEdeaf9bc9ef run function vf_eol_deaf9bc9ef:notice
