execute if score #phase vfEdeaf9bc9ef matches 1 run tellraw @a {"text": "[VortaForge EOL] vorta-core-67ee40093fb2: warning phase; function restrictions after 5184000 ticks and lock after 12096000 ticks (72 and 168 hours only at 20 TPS).", "color": "gold"}
execute if score #phase vfEdeaf9bc9ef matches 2 run tellraw @a {"text": "[VortaForge EOL] vorta-core-67ee40093fb2: restricted functions phase; non-function data and external commands are not blocked. Persistent world data is NOT erased.", "color": "gold"}
execute if score #phase vfEdeaf9bc9ef matches 3 run tellraw @a {"text": "[VortaForge EOL] vorta-core-67ee40093fb2: EOL locked. Use function vf_eol_deaf9bc9ef:status for lifecycle state.", "color": "gold"}
scoreboard players operation #last vfEdeaf9bc9ef = #phase vfEdeaf9bc9ef
