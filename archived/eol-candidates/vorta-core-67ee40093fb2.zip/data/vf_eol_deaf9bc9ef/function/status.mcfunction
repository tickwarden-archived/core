scoreboard players get #phase vfEdeaf9bc9ef
scoreboard players get #ticks vfEdeaf9bc9ef
scoreboard players get #cleaned vfEdeaf9bc9ef
