# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_f6ef270382:lifecycle {phase:1} run return 0
advancement revoke @s only click_detection:rc
function #click_detection:on_rc
