scoreboard players set #phase vfEf6ef270382 1
execute if score #ticks vfEf6ef270382 matches 5184000.. run scoreboard players set #phase vfEf6ef270382 2
execute if score #ticks vfEf6ef270382 matches 12096000.. run scoreboard players set #phase vfEf6ef270382 3
execute store result storage vf_eol_f6ef270382:lifecycle phase int 1 run scoreboard players get #phase vfEf6ef270382
