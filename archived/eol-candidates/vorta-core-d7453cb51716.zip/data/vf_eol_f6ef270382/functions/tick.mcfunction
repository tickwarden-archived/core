execute if score #phase vfEf6ef270382 matches 1..2 run scoreboard players add #ticks vfEf6ef270382 1
function vf_eol_f6ef270382:refresh
execute unless score #last vfEf6ef270382 = #phase vfEf6ef270382 run function vf_eol_f6ef270382:notice
execute if score #phase vfEf6ef270382 matches 3 if score #cleaned vfEf6ef270382 matches 0 run function vf_eol_f6ef270382:cleanup
