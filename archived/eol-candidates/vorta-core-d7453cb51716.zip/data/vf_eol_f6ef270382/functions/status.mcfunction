scoreboard players get #phase vfEf6ef270382
scoreboard players get #ticks vfEf6ef270382
scoreboard players get #cleaned vfEf6ef270382
