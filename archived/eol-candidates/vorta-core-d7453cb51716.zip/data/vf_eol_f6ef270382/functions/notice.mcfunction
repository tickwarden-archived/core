execute if score #phase vfEf6ef270382 matches 1 run tellraw @a {"text": "[VortaForge EOL] vorta-core-d7453cb51716: warning phase; read-only after 72 online hours, locked after 168 online hours at 20 TPS.", "color": "gold"}
execute if score #phase vfEf6ef270382 matches 2 run tellraw @a {"text": "[VortaForge EOL] vorta-core-d7453cb51716: restricted functions phase; non-function data and external commands are not blocked. Persistent world data is NOT erased.", "color": "gold"}
execute if score #phase vfEf6ef270382 matches 3 run tellraw @a {"text": "[VortaForge EOL] vorta-core-d7453cb51716: EOL locked. Use function vf_eol_f6ef270382:status for lifecycle state.", "color": "gold"}
scoreboard players operation #last vfEf6ef270382 = #phase vfEf6ef270382
