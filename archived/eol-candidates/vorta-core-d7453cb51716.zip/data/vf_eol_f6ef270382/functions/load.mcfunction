execute unless data storage vf_eol_f6ef270382:lifecycle initialized run scoreboard objectives add vfEf6ef270382 dummy
data modify storage vf_eol_f6ef270382:lifecycle initialized set value 1b
scoreboard players add #ticks vfEf6ef270382 0
scoreboard players add #phase vfEf6ef270382 0
scoreboard players add #last vfEf6ef270382 0
scoreboard players add #cleaned vfEf6ef270382 0
function vf_eol_f6ef270382:refresh
execute unless score #last vfEf6ef270382 = #phase vfEf6ef270382 run function vf_eol_f6ef270382:notice
