# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_cc1cb841d8:lifecycle {phase:1} run return 0
# ─────────────────────────────────────────────────────────────────
# macroengine:api/cmd/other/multi_cmd/advanced/internal/sort_append_loop
# Recursive: drain _sort_tmp into _mcmd_queue one item at a time.
# ─────────────────────────────────────────────────────────────────

execute unless data storage macroengine:engine _sort_tmp[0] run return 0

data modify storage macroengine:engine _mcmd_queue append from storage macroengine:engine _sort_tmp[0]
data remove storage macroengine:engine _sort_tmp[0]

function macroengine:core/internal/api/cmd/other/multi_cmd/advanced/sort_append_loop
