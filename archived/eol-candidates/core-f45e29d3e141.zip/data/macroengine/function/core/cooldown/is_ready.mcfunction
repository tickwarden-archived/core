# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_cc1cb841d8:lifecycle {phase:1} run return 0
# macroengine:core/cooldown/is_ready [MACRO]
$data modify storage macroengine:input player set value "$(player)"
$data modify storage macroengine:input key set value "$(key)"
function macroengine:core/cooldown/check with storage macroengine:input {}
# check: result=0b → cooldown active. is_ready returns the inverse.
execute if data storage macroengine:output {result:0b} run data modify storage macroengine:output result set value 1b
execute if data storage macroengine:output {result:1b} run data modify storage macroengine:output result set value 0b
