# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_cc1cb841d8:lifecycle {phase:1} run return 0
# ─────────────────────────────────────────────
# macroengine:api/macro/with_function [MACRO]
#
# Runs a provider (source) function; passes the data that function
# wrote to macroengine:engine _macro_pipe storage as macro variable source
# to a consumer (target) function.
#
# Establishes a type-safe data bridge between two functions.
#
# Usage:
#   function macroengine:api/macro/with_function \
#     {source:"ns:provider", target:"ns:consumer"}
#
# Parameters:
#   source — function that produces data and writes it to macroengine:engine _macro_pipe
#   target — function that consumes data from the pipe as macro variables
#
# Contract:
#   source function must write its output to this storage:
#     data modify storage macroengine:engine _macro_pipe.<key> set value <val>
#   target function can access those keys as $(key).
# ─────────────────────────────────────────────

# Run provider function — it writes its output to _macro_pipe
execute if data storage macroengine:engine modules{macro:0b} run return 0
$function $(source)

# Pass pipe to consumer as macro source
$function $(target) with storage macroengine:engine _macro_pipe

# Clear pipe before source runs
data remove storage macroengine:engine _macro_pipe
