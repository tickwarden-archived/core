# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_cc1cb841d8:lifecycle {phase:1} run return 0
# ─────────────────────────────────────────────────────────────────
# macroengine:api/wand/unregister
# Removes all wand binds belonging to a specific tag.
#
# INPUT (storage macroengine:input):
# tag → wand tag to remove
#
# EXAMPLE:
# data modify storage macroengine:input tag set value "fire_wand"
# function macroengine:api/wand/unregister
# ─────────────────────────────────────────────────────────────────

execute if data storage macroengine:engine modules{wand:0b} run return 0
function macroengine:core/internal/api/wand/unregister_exec with storage macroengine:input {}
