# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_cc1cb841d8:lifecycle {phase:1} run return 0
# macroengine:api/perm/revoke [MACRO]
execute if data storage macroengine:engine modules{perm:0b} run return 0
execute if entity @s unless entity @s[tag=macroengine.admin] run playsound macroengine:perm.denied master @s ~ ~ ~ 1 1
execute if entity @s unless entity @s[tag=macroengine.admin] run return run tellraw @s ["",{"text":"\uE000","color":"#00AAAA"},{"text":" ","color":"#00AAAA"},{"text":"✘ ","color":"red"},{"translate":"macroengine.msg.permission_denied","color":"red"}]

$data remove storage macroengine:engine permissions.$(player).$(perm)

scoreboard players set $prv_pid macroengine.tmp 0
$execute store result score $prv_pid macroengine.tmp run data get storage macroengine:engine player_pids.$(player)
$execute as @a if score @s macroengine.pid = $prv_pid macroengine.tmp run tag @s remove perm.$(perm)
$advancement revoke @a[name=$(player),limit=1] only macroengine:api/perm/$(perm)
