# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_cc1cb841d8:lifecycle {phase:1} run return 0
# macroengine:api/interaction/bind_attack
# Binds a function to an interaction entity attack event.
#
# INPUT:
#   macroengine:input tag  — entity tag to match
#   macroengine:input func — function to call on attack
#
# USAGE:
#   data modify storage macroengine:input tag set value "my_interact"
#   data modify storage macroengine:input func set value "mypack:on_attack"
#   function macroengine:api/interaction/bind_attack with storage macroengine:input {}
execute if data storage macroengine:engine modules{interaction:0b} run return 0
function macroengine:core/internal/api/interaction/bind_attack_do with storage macroengine:input {}
