# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_e938261fad:lifecycle {phase:1} run return 0
data modify storage rtwrapper:runtime queue set value []
