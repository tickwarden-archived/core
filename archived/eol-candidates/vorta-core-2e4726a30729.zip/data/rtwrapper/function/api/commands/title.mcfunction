# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_e938261fad:lifecycle {phase:1} run return 0
# Direct named-parameter API for /title.
# Parameter order: targets, action, title, fade_in, stay, fade_out
data modify storage rtwrapper:runtime current.params set from storage rtwrapper:api params
function rtwrapper:core/wrappers/internal/title
data remove storage rtwrapper:runtime current.params
