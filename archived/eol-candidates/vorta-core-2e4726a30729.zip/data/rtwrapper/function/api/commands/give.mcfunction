# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_e938261fad:lifecycle {phase:1} run return 0
# Direct named-parameter API for /give.
# Parameter order: target, item, count
data modify storage rtwrapper:runtime current.params set from storage rtwrapper:api params
function rtwrapper:core/wrappers/internal/give
data remove storage rtwrapper:runtime current.params
