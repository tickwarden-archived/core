# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_e938261fad:lifecycle {phase:1} run return 0
# Direct named-parameter API for /fetchprofile.
# Parameter order: name
data modify storage rtwrapper:runtime current.params set from storage rtwrapper:api params
function rtwrapper:core/wrappers/internal/fetchprofile
data remove storage rtwrapper:runtime current.params
