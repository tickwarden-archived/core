# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_e938261fad:lifecycle {phase:1} run return 0
# RTWrapper generated 3-parameter macro variant for /publish.
# Parameters: allow_commands, gamemode, port
$publish $(allow_commands) $(gamemode) $(port)
