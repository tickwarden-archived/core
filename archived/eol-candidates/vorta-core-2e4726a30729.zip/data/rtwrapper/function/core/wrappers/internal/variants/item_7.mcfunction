# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_e938261fad:lifecycle {phase:1} run return 0
# RTWrapper generated 7-parameter macro variant for /item.
# Parameters: action, target_kind, target, slot, modifier, source_kind, source
$item $(action) $(target_kind) $(target) $(slot) $(modifier) $(source_kind) $(source)
