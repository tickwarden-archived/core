# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_e938261fad:lifecycle {phase:1} run return 0
# RTWrapper generated 3-parameter macro variant for /playsound.
# Parameters: sound, source, targets
$playsound $(sound) $(source) $(targets)
