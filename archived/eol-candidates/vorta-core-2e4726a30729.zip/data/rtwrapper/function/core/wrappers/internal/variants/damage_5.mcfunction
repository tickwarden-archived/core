# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_e938261fad:lifecycle {phase:1} run return 0
# RTWrapper generated 5-parameter macro variant for /damage.
# Parameters: target, amount, damage_type, location_or_by, source
$damage $(target) $(amount) $(damage_type) $(location_or_by) $(source)
