# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_e938261fad:lifecycle {phase:1} run return 0
# RTWrapper generated 2-parameter macro variant for /execute.
# Parameters: step01, step02
$execute $(step01) $(step02)
