# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_e938261fad:lifecycle {phase:1} run return 0
# /publish has no safe/generated zero-parameter form in RTWrapper.
return fail
