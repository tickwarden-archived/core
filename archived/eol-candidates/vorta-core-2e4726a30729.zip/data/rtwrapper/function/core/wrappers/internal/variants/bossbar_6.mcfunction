# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_e938261fad:lifecycle {phase:1} run return 0
# RTWrapper generated 6-parameter macro variant for /bossbar.
# Parameters: action, id, name, property, value, players
$bossbar $(action) $(id) $(name) $(property) $(value) $(players)
