# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_55b54ff038:lifecycle {phase:1} run return 0
# vortex_example:callback/dispatch_handler
# Listed in #vortex:callback/dispatch, so it sees every callback. It only reads top (a copy of stack[-1])
# and never removes it; the runner pops the entry afterwards.
# AI-assisted: written with Claude (Anthropic); see CREDITS.md in the repo root.

execute if data storage vortex:callback top{id:"vortex_example:hello"} run function vortex_example:callback/on_hello
