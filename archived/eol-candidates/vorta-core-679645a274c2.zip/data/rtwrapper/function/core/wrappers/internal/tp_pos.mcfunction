# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_ce23931002:lifecycle {phase:1} run return 0
# Convenience macro wrapper for: /tp <target> <x> <y> <z>
# Required storage keys: target, x, y, z.
$tp $(target) $(x) $(y) $(z)
