# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_ce23931002:lifecycle {phase:1} run return 0
# RTWrapper generated 2-parameter macro variant for /playsound.
# Parameters: sound, source
$playsound $(sound) $(source)
