# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_ce23931002:lifecycle {phase:1} run return 0
# Convenience macro wrapper for: /teleport <targets> <x> <y> <z> <rotation>
# Required storage keys: targets, x, y, z, rotation.
$teleport $(targets) $(x) $(y) $(z) $(rotation)
