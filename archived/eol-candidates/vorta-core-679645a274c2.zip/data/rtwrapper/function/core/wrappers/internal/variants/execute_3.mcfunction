# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_ce23931002:lifecycle {phase:1} run return 0
# RTWrapper generated 3-parameter macro variant for /execute.
# Parameters: step01, step02, step03
$execute $(step01) $(step02) $(step03)
