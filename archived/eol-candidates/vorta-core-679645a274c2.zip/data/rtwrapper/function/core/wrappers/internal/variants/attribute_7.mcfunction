# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_ce23931002:lifecycle {phase:1} run return 0
# RTWrapper generated 7-parameter macro variant for /attribute.
# Parameters: target, attribute, action, value, modifier_id, modifier_value, modifier_operation
$attribute $(target) $(attribute) $(action) $(value) $(modifier_id) $(modifier_value) $(modifier_operation)
