# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_ce23931002:lifecycle {phase:1} run return 0
# RTWrapper generated 1-parameter macro variant for /pardon-ip.
# Parameters: target
$pardon-ip $(target)
