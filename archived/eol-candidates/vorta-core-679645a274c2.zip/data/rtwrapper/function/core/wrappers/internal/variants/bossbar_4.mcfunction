# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_ce23931002:lifecycle {phase:1} run return 0
# RTWrapper generated 4-parameter macro variant for /bossbar.
# Parameters: action, id, name, property
$bossbar $(action) $(id) $(name) $(property)
