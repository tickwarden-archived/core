# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_ce23931002:lifecycle {phase:1} run return 0
# /chase has no safe/generated zero-parameter form in RTWrapper.
return fail
