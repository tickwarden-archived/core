# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_ce23931002:lifecycle {phase:1} run return 0
# RTWrapper generated named-parameter dispatcher for /debugconfig.
# Provide contiguous parameters in this order:
# action, option, value
scoreboard players set #pc rtw.status 0
execute if data storage rtwrapper:runtime current.params.action run scoreboard players set #pc rtw.status 1
execute if data storage rtwrapper:runtime current.params.option run scoreboard players set #pc rtw.status 2
execute if data storage rtwrapper:runtime current.params.value run scoreboard players set #pc rtw.status 3
execute if score #pc rtw.status matches 0 run function rtwrapper:core/wrappers/internal/variants/debugconfig_0
execute if score #pc rtw.status matches 1 run function rtwrapper:core/wrappers/internal/variants/debugconfig_1 with storage rtwrapper:runtime current.params
execute if score #pc rtw.status matches 2 run function rtwrapper:core/wrappers/internal/variants/debugconfig_2 with storage rtwrapper:runtime current.params
execute if score #pc rtw.status matches 3 run function rtwrapper:core/wrappers/internal/variants/debugconfig_3 with storage rtwrapper:runtime current.params
