# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_ce23931002:lifecycle {phase:1} run return 0
# RTWrapper generated 3-parameter macro variant for /particle.
# Parameters: particle, pos, delta
$particle $(particle) $(pos) $(delta)
