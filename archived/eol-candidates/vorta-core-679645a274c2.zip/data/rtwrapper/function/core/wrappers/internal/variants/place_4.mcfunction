# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_ce23931002:lifecycle {phase:1} run return 0
# RTWrapper generated 4-parameter macro variant for /place.
# Parameters: type, id, pos, rotation
$place $(type) $(id) $(pos) $(rotation)
