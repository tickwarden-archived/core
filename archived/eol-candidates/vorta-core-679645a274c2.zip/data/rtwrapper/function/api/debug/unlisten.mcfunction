# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_ce23931002:lifecycle {phase:1} run return 0
tag @s remove rtwrapper.debug
tellraw @s [{"text":"[RTWrapper] debug listener removed","color":"gold"}]
