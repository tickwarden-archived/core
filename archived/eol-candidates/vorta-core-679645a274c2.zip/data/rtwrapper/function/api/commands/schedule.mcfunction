# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_ce23931002:lifecycle {phase:1} run return 0
# Direct named-parameter API for /schedule.
# Parameter order: action, function_id, time, mode
data modify storage rtwrapper:runtime current.params set from storage rtwrapper:api params
function rtwrapper:core/wrappers/internal/schedule
data remove storage rtwrapper:runtime current.params
