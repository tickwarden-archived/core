# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_ce23931002:lifecycle {phase:1} run return 0
scoreboard players set #silent rtw.config 0
data modify storage rtwrapper:runtime config.silent set value 0b
tellraw @s [{"text":"[RTWrapper] silent off","color":"gold"}]
