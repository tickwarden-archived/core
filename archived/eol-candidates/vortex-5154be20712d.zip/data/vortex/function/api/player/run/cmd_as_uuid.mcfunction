# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_63b504a29e:lifecycle {phase:1} run return 0
# vortex:api/player/run/cmd_as_uuid [MACRO]
$execute as @a[nbt={UUID:$(uuid)}] run $(cmd)
