# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_63b504a29e:lifecycle {phase:1} run return 0
# vortex:api/dialog/state_clear
function vortex:core/internal/dialog/context
function vortex:core/internal/dialog/state_clear with storage vortex:dialog_ctx
