# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_63b504a29e:lifecycle {phase:1} run return 0
# vortex:api/title/broadcast — Broadcast title + subtitle + times to all players [MACRO]
# Sends a complete title display (timing + title + subtitle) to every online player.
# Unlike cmd/title_all which only sends a plain title to @a with no subtitle or
# timing control, this sets times and subtitle in the same atomic call.
#
# Input (macro args):
#   title     — title text
#   subtitle  — subtitle text
#   color     — title color    (e.g. "red", "#RRGGBB")
#   sub_color — subtitle color (e.g. "yellow", "#RRGGBB")
#   fade_in   — ticks to fade in  (e.g. 20)
#   stay      — ticks to stay     (e.g. 100)
#   fade_out  — ticks to fade out (e.g. 20)
#
# Output → none
#
# Usage:
#   function vortex:api/title/broadcast {title:"Server restart in 5 min",\
#     subtitle:"Save your progress!",color:"red",sub_color:"yellow",\
#     fade_in:20,stay:100,fade_out:20}$title @a times $(fade_in) $(stay) $(fade_out)
execute if data storage vortex:engine modules{title:0b} run return 0
$title @a title {"text":"$(title)","color":"$(color)"}
$title @a subtitle {"text":"$(subtitle)","color":"$(sub_color)"}
