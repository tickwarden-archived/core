scoreboard players set #phase vfEf4ecdd3c20 1
execute if score #ticks vfEf4ecdd3c20 matches 5184000.. run scoreboard players set #phase vfEf4ecdd3c20 2
execute if score #ticks vfEf4ecdd3c20 matches 12096000.. run scoreboard players set #phase vfEf4ecdd3c20 3
execute store result storage vf_eol_f4ecdd3c20:lifecycle phase int 1 run scoreboard players get #phase vfEf4ecdd3c20
