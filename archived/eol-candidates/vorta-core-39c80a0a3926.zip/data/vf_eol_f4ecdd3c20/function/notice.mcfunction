execute if score #phase vfEf4ecdd3c20 matches 1 run tellraw @a {"text": "[VortaForge EOL] vorta-core-39c80a0a3926: warning phase; function restrictions after 5184000 ticks and lock after 12096000 ticks (72 and 168 hours only at 20 TPS).", "color": "gold"}
execute if score #phase vfEf4ecdd3c20 matches 2 run tellraw @a {"text": "[VortaForge EOL] vorta-core-39c80a0a3926: restricted functions phase; non-function data and external commands are not blocked. Persistent world data is NOT erased.", "color": "gold"}
execute if score #phase vfEf4ecdd3c20 matches 3 run tellraw @a {"text": "[VortaForge EOL] vorta-core-39c80a0a3926: EOL locked. Use function vf_eol_f4ecdd3c20:status for lifecycle state.", "color": "gold"}
scoreboard players operation #last vfEf4ecdd3c20 = #phase vfEf4ecdd3c20
