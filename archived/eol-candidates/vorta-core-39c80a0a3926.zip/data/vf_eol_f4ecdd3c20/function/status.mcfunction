scoreboard players get #phase vfEf4ecdd3c20
scoreboard players get #ticks vfEf4ecdd3c20
scoreboard players get #cleaned vfEf4ecdd3c20
