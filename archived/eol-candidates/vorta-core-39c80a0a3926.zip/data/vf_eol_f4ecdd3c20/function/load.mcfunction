execute unless data storage vf_eol_f4ecdd3c20:lifecycle initialized run scoreboard objectives add vfEf4ecdd3c20 dummy
data modify storage vf_eol_f4ecdd3c20:lifecycle initialized set value 1b
scoreboard players add #ticks vfEf4ecdd3c20 0
scoreboard players add #phase vfEf4ecdd3c20 0
scoreboard players add #last vfEf4ecdd3c20 0
scoreboard players add #cleaned vfEf4ecdd3c20 0
function vf_eol_f4ecdd3c20:refresh
execute unless score #last vfEf4ecdd3c20 = #phase vfEf4ecdd3c20 run function vf_eol_f4ecdd3c20:notice
