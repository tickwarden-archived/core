execute if score #phase vfEf4ecdd3c20 matches 1..2 run scoreboard players add #ticks vfEf4ecdd3c20 1
function vf_eol_f4ecdd3c20:refresh
execute unless score #last vfEf4ecdd3c20 = #phase vfEf4ecdd3c20 run function vf_eol_f4ecdd3c20:notice
execute if score #phase vfEf4ecdd3c20 matches 3 if score #cleaned vfEf4ecdd3c20 matches 0 run function vf_eol_f4ecdd3c20:cleanup
