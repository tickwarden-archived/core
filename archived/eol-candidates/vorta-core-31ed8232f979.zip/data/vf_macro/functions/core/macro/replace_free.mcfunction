# EOL entry guard; legacy Minecraft requires each command to be gated.
execute if data storage vf_eol_c2b130d1d1:lifecycle {phase:1} run scoreboard players set #vf_macro.free_done vf_macro 1
