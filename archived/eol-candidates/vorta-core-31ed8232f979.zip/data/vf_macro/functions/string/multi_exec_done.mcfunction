# EOL entry guard; legacy Minecraft requires each command to be gated.
execute if data storage vf_eol_c2b130d1d1:lifecycle {phase:1} run function vf_macro:core/cleanup
execute if data storage vf_eol_c2b130d1d1:lifecycle {phase:1} run scoreboard players set #vf_macro.force_ok vf_macro 1
