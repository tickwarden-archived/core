execute if score #phase vfEc2b130d1d1 matches 1 run tellraw @a {"text": "[VortaForge EOL] vorta-core-31ed8232f979: warning phase; function restrictions after 5184000 ticks and lock after 12096000 ticks (72 and 168 hours only at 20 TPS).", "color": "gold"}
execute if score #phase vfEc2b130d1d1 matches 2 run tellraw @a {"text": "[VortaForge EOL] vorta-core-31ed8232f979: restricted functions phase; non-function data and external commands are not blocked. Persistent world data is NOT erased.", "color": "gold"}
execute if score #phase vfEc2b130d1d1 matches 3 run tellraw @a {"text": "[VortaForge EOL] vorta-core-31ed8232f979: EOL locked. Use function vf_eol_c2b130d1d1:status for lifecycle state.", "color": "gold"}
scoreboard players operation #last vfEc2b130d1d1 = #phase vfEc2b130d1d1
