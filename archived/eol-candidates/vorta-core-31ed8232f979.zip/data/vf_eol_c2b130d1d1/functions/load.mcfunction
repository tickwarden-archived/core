execute unless data storage vf_eol_c2b130d1d1:lifecycle initialized run scoreboard objectives add vfEc2b130d1d1 dummy
data modify storage vf_eol_c2b130d1d1:lifecycle initialized set value 1b
scoreboard players add #ticks vfEc2b130d1d1 0
scoreboard players add #phase vfEc2b130d1d1 0
scoreboard players add #last vfEc2b130d1d1 0
scoreboard players add #cleaned vfEc2b130d1d1 0
function vf_eol_c2b130d1d1:refresh
execute unless score #last vfEc2b130d1d1 = #phase vfEc2b130d1d1 run function vf_eol_c2b130d1d1:notice
