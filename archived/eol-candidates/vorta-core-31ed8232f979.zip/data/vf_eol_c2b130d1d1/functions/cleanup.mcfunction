# No automatic schedule clearing: function identifiers may be shared across packs.
# No world, player, storage, objective or entity deletion.
scoreboard players set #cleaned vfEc2b130d1d1 1
