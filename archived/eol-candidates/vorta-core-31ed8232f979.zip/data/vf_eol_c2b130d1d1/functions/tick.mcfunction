execute if score #phase vfEc2b130d1d1 matches 1..2 run scoreboard players add #ticks vfEc2b130d1d1 1
function vf_eol_c2b130d1d1:refresh
execute unless score #last vfEc2b130d1d1 = #phase vfEc2b130d1d1 run function vf_eol_c2b130d1d1:notice
execute if score #phase vfEc2b130d1d1 matches 3 if score #cleaned vfEc2b130d1d1 matches 0 run function vf_eol_c2b130d1d1:cleanup
