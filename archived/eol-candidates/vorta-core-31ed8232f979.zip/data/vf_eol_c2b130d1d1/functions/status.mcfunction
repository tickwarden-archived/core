scoreboard players get #phase vfEc2b130d1d1
scoreboard players get #ticks vfEc2b130d1d1
scoreboard players get #cleaned vfEc2b130d1d1
