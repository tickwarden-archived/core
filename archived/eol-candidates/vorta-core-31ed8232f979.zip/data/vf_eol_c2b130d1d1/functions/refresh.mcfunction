scoreboard players set #phase vfEc2b130d1d1 1
execute if score #ticks vfEc2b130d1d1 matches 5184000.. run scoreboard players set #phase vfEc2b130d1d1 2
execute if score #ticks vfEc2b130d1d1 matches 12096000.. run scoreboard players set #phase vfEc2b130d1d1 3
execute store result storage vf_eol_c2b130d1d1:lifecycle phase int 1 run scoreboard players get #phase vfEc2b130d1d1
