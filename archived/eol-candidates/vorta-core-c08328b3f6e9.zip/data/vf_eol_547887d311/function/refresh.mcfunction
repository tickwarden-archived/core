scoreboard players set #phase vfE547887d311 1
execute if score #ticks vfE547887d311 matches 5184000.. run scoreboard players set #phase vfE547887d311 2
execute if score #ticks vfE547887d311 matches 12096000.. run scoreboard players set #phase vfE547887d311 3
execute store result storage vf_eol_547887d311:lifecycle phase int 1 run scoreboard players get #phase vfE547887d311
