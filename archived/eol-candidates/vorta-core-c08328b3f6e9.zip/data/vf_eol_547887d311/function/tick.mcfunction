execute if score #phase vfE547887d311 matches 1..2 run scoreboard players add #ticks vfE547887d311 1
function vf_eol_547887d311:refresh
execute unless score #last vfE547887d311 = #phase vfE547887d311 run function vf_eol_547887d311:notice
execute if score #phase vfE547887d311 matches 3 if score #cleaned vfE547887d311 matches 0 run function vf_eol_547887d311:cleanup
