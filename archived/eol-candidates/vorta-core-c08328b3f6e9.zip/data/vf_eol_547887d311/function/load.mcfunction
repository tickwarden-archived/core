execute unless data storage vf_eol_547887d311:lifecycle initialized run scoreboard objectives add vfE547887d311 dummy
data modify storage vf_eol_547887d311:lifecycle initialized set value 1b
scoreboard players add #ticks vfE547887d311 0
scoreboard players add #phase vfE547887d311 0
scoreboard players add #last vfE547887d311 0
scoreboard players add #cleaned vfE547887d311 0
function vf_eol_547887d311:refresh
execute unless score #last vfE547887d311 = #phase vfE547887d311 run function vf_eol_547887d311:notice
