execute if score #phase vfE547887d311 matches 1 run tellraw @a {"text": "[VortaForge EOL] vorta-core-c08328b3f6e9: warning phase; read-only after 72 online hours, locked after 168 online hours at 20 TPS.", "color": "gold"}
execute if score #phase vfE547887d311 matches 2 run tellraw @a {"text": "[VortaForge EOL] vorta-core-c08328b3f6e9: restricted functions phase; non-function data and external commands are not blocked. Persistent world data is NOT erased.", "color": "gold"}
execute if score #phase vfE547887d311 matches 3 run tellraw @a {"text": "[VortaForge EOL] vorta-core-c08328b3f6e9: EOL locked. Use function vf_eol_547887d311:status for lifecycle state.", "color": "gold"}
scoreboard players operation #last vfE547887d311 = #phase vfE547887d311
