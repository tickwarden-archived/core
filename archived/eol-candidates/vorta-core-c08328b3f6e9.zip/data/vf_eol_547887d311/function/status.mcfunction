scoreboard players get #phase vfE547887d311
scoreboard players get #ticks vfE547887d311
scoreboard players get #cleaned vfE547887d311
