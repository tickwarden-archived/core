# No automatic schedule clearing: function identifiers may be shared across packs.
# No world, player, storage, objective or entity deletion.
scoreboard players set #cleaned vfE547887d311 1
