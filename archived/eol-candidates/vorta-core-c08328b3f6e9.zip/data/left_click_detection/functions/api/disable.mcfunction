# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_547887d311:lifecycle {phase:1} run return 0
#> left_click_detection:api/disable
#
# 実行者の左クリック検知を無効化します
#
# @api

function left_click_detection:core/detail/disable
