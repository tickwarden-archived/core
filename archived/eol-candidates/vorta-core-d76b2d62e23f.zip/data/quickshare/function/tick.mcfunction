# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_ec21c0a2c4:lifecycle {phase:1} run return 0
# Ticks down each player's cooldown, floored at 0
execute as @a[scores={qs_cooldown=1..}] run scoreboard players remove @s qs_cooldown 1
