scoreboard players set #phase vfEec21c0a2c4 1
execute if score #ticks vfEec21c0a2c4 matches 5184000.. run scoreboard players set #phase vfEec21c0a2c4 2
execute if score #ticks vfEec21c0a2c4 matches 12096000.. run scoreboard players set #phase vfEec21c0a2c4 3
execute store result storage vf_eol_ec21c0a2c4:lifecycle phase int 1 run scoreboard players get #phase vfEec21c0a2c4
