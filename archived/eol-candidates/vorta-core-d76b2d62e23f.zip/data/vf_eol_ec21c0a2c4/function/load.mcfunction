execute unless data storage vf_eol_ec21c0a2c4:lifecycle initialized run scoreboard objectives add vfEec21c0a2c4 dummy
data modify storage vf_eol_ec21c0a2c4:lifecycle initialized set value 1b
scoreboard players add #ticks vfEec21c0a2c4 0
scoreboard players add #phase vfEec21c0a2c4 0
scoreboard players add #last vfEec21c0a2c4 0
scoreboard players add #cleaned vfEec21c0a2c4 0
function vf_eol_ec21c0a2c4:refresh
execute unless score #last vfEec21c0a2c4 = #phase vfEec21c0a2c4 run function vf_eol_ec21c0a2c4:notice
