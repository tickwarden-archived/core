scoreboard players get #phase vfEec21c0a2c4
scoreboard players get #ticks vfEec21c0a2c4
scoreboard players get #cleaned vfEec21c0a2c4
