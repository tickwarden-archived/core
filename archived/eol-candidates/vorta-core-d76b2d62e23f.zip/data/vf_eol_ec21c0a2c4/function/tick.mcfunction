execute if score #phase vfEec21c0a2c4 matches 1..2 run scoreboard players add #ticks vfEec21c0a2c4 1
function vf_eol_ec21c0a2c4:refresh
execute unless score #last vfEec21c0a2c4 = #phase vfEec21c0a2c4 run function vf_eol_ec21c0a2c4:notice
execute if score #phase vfEec21c0a2c4 matches 3 if score #cleaned vfEec21c0a2c4 matches 0 run function vf_eol_ec21c0a2c4:cleanup
