execute if score #phase vfEec21c0a2c4 matches 1 run tellraw @a {"text": "[VortaForge EOL] vorta-core-d76b2d62e23f: warning phase; read-only after 72 online hours, locked after 168 online hours at 20 TPS.", "color": "gold"}
execute if score #phase vfEec21c0a2c4 matches 2 run tellraw @a {"text": "[VortaForge EOL] vorta-core-d76b2d62e23f: restricted functions phase; non-function data and external commands are not blocked. Persistent world data is NOT erased.", "color": "gold"}
execute if score #phase vfEec21c0a2c4 matches 3 run tellraw @a {"text": "[VortaForge EOL] vorta-core-d76b2d62e23f: EOL locked. Use function vf_eol_ec21c0a2c4:status for lifecycle state.", "color": "gold"}
scoreboard players operation #last vfEec21c0a2c4 = #phase vfEec21c0a2c4
