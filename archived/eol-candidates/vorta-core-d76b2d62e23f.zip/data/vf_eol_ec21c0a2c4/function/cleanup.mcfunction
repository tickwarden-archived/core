# No automatic schedule clearing: function identifiers may be shared across packs.
# No world, player, storage, objective or entity deletion.
scoreboard players set #cleaned vfEec21c0a2c4 1
