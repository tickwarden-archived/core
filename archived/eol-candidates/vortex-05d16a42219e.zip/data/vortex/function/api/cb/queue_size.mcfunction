# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_8ca60b8329:lifecycle {phase:1} run return 0
# vortex:api/cb/queue_size
# ─────────────────────────────────────────────────────────────────
# Returns the number of pending delayed CB commands.
# Result is stored in score #cb_queue_size vortex.tmp.
#
# EXAMPLE:
#   function vortex:api/cb/queue_size
#   # read: scoreboard players get #cb_queue_size vortex.tmp
# ─────────────────────────────────────────────────────────────────

execute if data storage vortex:engine modules{cb:0b} run return 0
execute store result score #cb_queue_size vortex.tmp run data get storage vortex:engine cb_queue
