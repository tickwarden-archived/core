# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_8ca60b8329:lifecycle {phase:1} run return 0
# ======================================================================================
# vortex:api/input/validate/check
# ======================================================================================
#
# TYPE-SAFETY GUARD FOR CAPTURED PLAYER INPUT.
#
# Every input capture point (book_capture, cbm_capture) only
# ever stores the RAW string a player submitted — it does not know or care
# whether that string is the shape the caller actually needs. This function
# is the missing check: run it AFTER a capture, BEFORE you use the value as
# a number, bool, or safe scoreboard/tag literal.
#
# THIS DOES NOT EXECUTE THE INPUT. It only reads it and reports pass/fail.
#
# CALL WITH:
#   function vortex:api/input/validate/check with storage <yourpath> {source: "<path.to.field>", type: "int"|"float"|"bool"|"tag_safe"}
#
#   $(source) — a dot-path INTO vortex:input, e.g. "book.raw",
#               "cbm.command". Read via macro from vortex:input directly.
#   $(type)   — one of:
#       "int"      — string must parse as a whole number (optional leading -)
#       "float"    — string must parse as int or decimal (optional leading -)
#       "bool"     — string must be exactly "true" or "false"
#       "tag_safe" — string must contain none of: space, ", ', {, }, [, ], :,
#                    the literal backslash character, or be empty. Safe to use
#                    as a scoreboard objective/player name fragment or a
#                    single unquoted NBT string component.
#
# OUTPUT (written to storage vortex:input_validate result):
#   result.valid    — 1b if input matches the requested type, else 0b
#   result.error    — human-readable reason when invalid (unset when valid)
#   result.value    — for "int"/"float": the raw string, unchanged (the caller still
#                     owns turning it into a real number, via
#                     vortex:core/internal/core/lib/string/to_number, after checking result.valid)
#
# THIS FUNCTION NEVER $$(...) MACRO-EXECUTES THE INPUT STRING. The checks run in
# vortex:core/internal/text, which looks at one character at a time and never
# substitutes the input as a whole into a command line.
# ======================================================================================

data remove storage vortex:input_validate result
data modify storage vortex:input_validate result.valid set value 0b

$data modify storage vortex:input_validate scratch.value set from storage vortex:input $(source)
$data modify storage vortex:input_validate scratch.type set value "$(type)"

execute if data storage vortex:input_validate {scratch:{type:"int"}} run function vortex:core/internal/input/validate/_private/check_int
execute if data storage vortex:input_validate {scratch:{type:"float"}} run function vortex:core/internal/input/validate/_private/check_float
execute if data storage vortex:input_validate {scratch:{type:"bool"}} run function vortex:core/internal/input/validate/_private/check_bool
execute if data storage vortex:input_validate {scratch:{type:"tag_safe"}} run function vortex:core/internal/input/validate/_private/check_tag_safe

data remove storage vortex:input_validate scratch
