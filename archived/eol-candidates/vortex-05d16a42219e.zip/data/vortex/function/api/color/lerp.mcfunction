# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_8ca60b8329:lifecycle {phase:1} run return 0
# vortex:api/color/lerp [MACRO]
# Looks up a precomputed lerp step from a named gradient table.
# Gradients are registered via vortex:api/color/gradient_set.
#
# This is NOT a real-time RGB interpolator — mcfunction cannot do
# per-channel arithmetic at runtime. Instead, callers pre-register
# a gradient as an ordered list of hex strings and this function
# returns the entry at the given step index.
#
# Input (macro args):
#   gradient — gradient name registered via gradient_set
#   step     — integer index into the gradient list (0-based)
#
# Output → vortex:output result
#   The color string at that step, or "" if out of range.
#
# Usage:
#   # Register once (e.g. at load):
#   function vortex:api/color/gradient_set {name:"sunset",\
#     colors:["#FF0000","#FF5500","#FFAA00","#FFD700","#FFFF00"]}
#
#   # Retrieve at runtime:
#   function vortex:api/color/lerp {gradient:"sunset",step:2}
#   # → vortex:output result = "#FFAA00"

execute if data storage vortex:engine modules{color:0b} run return 0
data modify storage vortex:output result set value ""
$data modify storage vortex:engine _color_lerp_tmp set value {gradient:"$(gradient)",step:$(step)}
$execute if data storage vortex:engine color.gradients.$(gradient) run function vortex:core/internal/systems/color/lerp_exec with storage vortex:engine _color_lerp_tmp
