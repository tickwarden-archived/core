# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_3ee855b6da:lifecycle {phase:1} run return 0
#> This function will run on datapack loading
