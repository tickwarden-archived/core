execute if score #phase vfE3ee855b6da matches 1 run tellraw @a {"text": "[VortaForge EOL] vorta-core-6b1b3ffb7baa: warning phase; function restrictions after 5184000 ticks and lock after 12096000 ticks (72 and 168 hours only at 20 TPS).", "color": "gold"}
execute if score #phase vfE3ee855b6da matches 2 run tellraw @a {"text": "[VortaForge EOL] vorta-core-6b1b3ffb7baa: restricted functions phase; non-function data and external commands are not blocked. Persistent world data is NOT erased.", "color": "gold"}
execute if score #phase vfE3ee855b6da matches 3 run tellraw @a {"text": "[VortaForge EOL] vorta-core-6b1b3ffb7baa: EOL locked. Use function vf_eol_3ee855b6da:status for lifecycle state.", "color": "gold"}
scoreboard players operation #last vfE3ee855b6da = #phase vfE3ee855b6da
