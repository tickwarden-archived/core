execute if score #phase vfE3ee855b6da matches 1..2 run scoreboard players add #ticks vfE3ee855b6da 1
function vf_eol_3ee855b6da:refresh
execute unless score #last vfE3ee855b6da = #phase vfE3ee855b6da run function vf_eol_3ee855b6da:notice
execute if score #phase vfE3ee855b6da matches 3 if score #cleaned vfE3ee855b6da matches 0 run function vf_eol_3ee855b6da:cleanup
