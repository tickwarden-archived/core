execute unless data storage vf_eol_3ee855b6da:lifecycle initialized run scoreboard objectives add vfE3ee855b6da dummy
data modify storage vf_eol_3ee855b6da:lifecycle initialized set value 1b
scoreboard players add #ticks vfE3ee855b6da 0
scoreboard players add #phase vfE3ee855b6da 0
scoreboard players add #last vfE3ee855b6da 0
scoreboard players add #cleaned vfE3ee855b6da 0
function vf_eol_3ee855b6da:refresh
execute unless score #last vfE3ee855b6da = #phase vfE3ee855b6da run function vf_eol_3ee855b6da:notice
