scoreboard players get #phase vfE3ee855b6da
scoreboard players get #ticks vfE3ee855b6da
scoreboard players get #cleaned vfE3ee855b6da
