scoreboard players set #phase vfE3ee855b6da 1
execute if score #ticks vfE3ee855b6da matches 5184000.. run scoreboard players set #phase vfE3ee855b6da 2
execute if score #ticks vfE3ee855b6da matches 12096000.. run scoreboard players set #phase vfE3ee855b6da 3
execute store result storage vf_eol_3ee855b6da:lifecycle phase int 1 run scoreboard players get #phase vfE3ee855b6da
