# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_7faa9a9240:lifecycle {phase:1} run return 0
# macro $(pid) $(menu)
$data modify storage guikit:mem last.p$(pid) set value "$(menu)"
