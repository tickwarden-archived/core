# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_7faa9a9240:lifecycle {phase:1} run return 0
# macro $(id)
$execute if data storage guikit:lib menus.$(id) run scoreboard players set #ok guikit.const 1
$execute unless data storage guikit:lib menus.$(id) run scoreboard players set #ok guikit.const 0
