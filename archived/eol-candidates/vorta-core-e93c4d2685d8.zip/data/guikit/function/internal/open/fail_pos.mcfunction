# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_7faa9a9240:lifecycle {phase:1} run return 0
tellraw @s [{"text":"[guikit] ","color":"gold"},{"text":"Block container requires pos:[x,y,z] on the menu.","color":"red"}]
scoreboard players set #ok guikit.const 0
