# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_7faa9a9240:lifecycle {phase:1} run return 0
tellraw @s [{"text":"[guikit] ","color":"gold"},{"text":"Could not open menu (container spawn failed).","color":"red"}]
scoreboard players set #ok guikit.const 0
