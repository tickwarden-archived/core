# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_7faa9a9240:lifecycle {phase:1} run return 0
# Dispatch widget kind → widget/<kind> place + record action if interactive
data modify storage guikit:work kind set from storage guikit:draw w.kind
function guikit:internal/draw/one_kind with storage guikit:work
