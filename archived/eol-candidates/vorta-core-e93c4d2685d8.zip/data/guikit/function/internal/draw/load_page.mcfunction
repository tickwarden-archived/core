# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_7faa9a9240:lifecycle {phase:1} run return 0
# macro $(page)
$data modify storage guikit:draw widgets set from storage guikit:draw menu.pages[$(page)].widgets
