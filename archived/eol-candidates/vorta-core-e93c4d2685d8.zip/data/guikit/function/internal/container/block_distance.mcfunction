# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_7faa9a9240:lifecycle {phase:1} run return 0
scoreboard players set #far guikit.tmp 0
function guikit:internal/container/load_pos
function guikit:internal/container/block_distance_do with storage guikit:work
