# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_7faa9a9240:lifecycle {phase:1} run return 0
# macro $(x) $(y) $(z)
$execute if block $(x) $(y) $(z) #guikit:gui_blocks run scoreboard players set #present guikit.tmp 1
