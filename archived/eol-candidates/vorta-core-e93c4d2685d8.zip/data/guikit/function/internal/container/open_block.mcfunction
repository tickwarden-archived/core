# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_7faa9a9240:lifecycle {phase:1} run return 0
scoreboard players set #ok guikit.const 1
function guikit:internal/container/place_block
execute unless score @s guikit.mode matches 1 run scoreboard players set #ok guikit.const 0
