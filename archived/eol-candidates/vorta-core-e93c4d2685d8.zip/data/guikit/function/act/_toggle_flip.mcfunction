# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_7faa9a9240:lifecycle {phase:1} run return 0
# macro $(key)
$execute if score @s $(key) matches 1 run scoreboard players set #tog guikit.tmp 0
$execute unless score @s $(key) matches 1 run scoreboard players set #tog guikit.tmp 1
$scoreboard players operation @s $(key) = #tog guikit.tmp
