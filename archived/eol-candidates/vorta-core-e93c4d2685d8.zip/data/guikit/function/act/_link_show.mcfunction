# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_7faa9a9240:lifecycle {phase:1} run return 0
# macro $(url)
$tellraw @s [{"text":"[guikit] ","color":"gold"},{"text":"Open link: ","color":"gray"},{"text":"$(url)","color":"aqua","underlined":true,"click_event":{"action":"open_url","url":"$(url)"}}]
