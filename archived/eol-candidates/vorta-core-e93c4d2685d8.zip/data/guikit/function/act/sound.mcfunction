# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_7faa9a9240:lifecycle {phase:1} run return 0
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.7 1.2
