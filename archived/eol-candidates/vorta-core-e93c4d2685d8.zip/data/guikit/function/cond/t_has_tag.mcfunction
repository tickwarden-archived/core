# EOL entry guard; see vortaforge-eol.json
execute unless data storage vf_eol_7faa9a9240:lifecycle {phase:1} run return 0
scoreboard players set #cond guikit.tmp 0
data modify storage guikit:work tag set from storage guikit:cond tag
function guikit:cond/t_has_tag_do with storage guikit:work
