execute if score #phase vfE7faa9a9240 matches 1..2 run scoreboard players add #ticks vfE7faa9a9240 1
function vf_eol_7faa9a9240:refresh
execute unless score #last vfE7faa9a9240 = #phase vfE7faa9a9240 run function vf_eol_7faa9a9240:notice
execute if score #phase vfE7faa9a9240 matches 3 if score #cleaned vfE7faa9a9240 matches 0 run function vf_eol_7faa9a9240:cleanup
