execute unless data storage vf_eol_7faa9a9240:lifecycle initialized run scoreboard objectives add vfE7faa9a9240 dummy
data modify storage vf_eol_7faa9a9240:lifecycle initialized set value 1b
scoreboard players add #ticks vfE7faa9a9240 0
scoreboard players add #phase vfE7faa9a9240 0
scoreboard players add #last vfE7faa9a9240 0
scoreboard players add #cleaned vfE7faa9a9240 0
function vf_eol_7faa9a9240:refresh
execute unless score #last vfE7faa9a9240 = #phase vfE7faa9a9240 run function vf_eol_7faa9a9240:notice
