execute if score #phase vfE7faa9a9240 matches 1 run tellraw @a {"text": "[VortaForge EOL] vorta-core-e93c4d2685d8: warning phase; function restrictions after 5184000 ticks and lock after 12096000 ticks (72 and 168 hours only at 20 TPS).", "color": "gold"}
execute if score #phase vfE7faa9a9240 matches 2 run tellraw @a {"text": "[VortaForge EOL] vorta-core-e93c4d2685d8: restricted functions phase; non-function data and external commands are not blocked. Persistent world data is NOT erased.", "color": "gold"}
execute if score #phase vfE7faa9a9240 matches 3 run tellraw @a {"text": "[VortaForge EOL] vorta-core-e93c4d2685d8: EOL locked. Use function vf_eol_7faa9a9240:status for lifecycle state.", "color": "gold"}
scoreboard players operation #last vfE7faa9a9240 = #phase vfE7faa9a9240
