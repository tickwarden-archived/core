scoreboard players set #phase vfE7faa9a9240 1
execute if score #ticks vfE7faa9a9240 matches 5184000.. run scoreboard players set #phase vfE7faa9a9240 2
execute if score #ticks vfE7faa9a9240 matches 12096000.. run scoreboard players set #phase vfE7faa9a9240 3
execute store result storage vf_eol_7faa9a9240:lifecycle phase int 1 run scoreboard players get #phase vfE7faa9a9240
