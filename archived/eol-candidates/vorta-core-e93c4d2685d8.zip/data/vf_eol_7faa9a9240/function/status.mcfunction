scoreboard players get #phase vfE7faa9a9240
scoreboard players get #ticks vfE7faa9a9240
scoreboard players get #cleaned vfE7faa9a9240
