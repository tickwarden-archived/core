# vortex:input/give/name_tag
# Gives a marked name_tag ready for input capture.
# The player renames it (via anvil) then holds it to submit.
give @s minecraft:name_tag[minecraft:custom_data={vortex:{input:1b,inputItem:"name_tag"}}] 1
