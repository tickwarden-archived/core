# vortex:player/get/xp [MACRO]
data modify storage vortex:output found set value 0b

$execute unless entity @a[name=$(player),limit=1] run return 0

data modify storage vortex:output found set value 1b
$execute as @a[name=$(player),limit=1] store result storage vortex:output level int 1 run data get entity @s XpLevel
$execute as @a[name=$(player),limit=1] store result storage vortex:output points int 1 run xp query @s points
$execute as @a[name=$(player),limit=1] store result storage vortex:output progress int 1000 run data get entity @s XpP
