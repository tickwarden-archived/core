# ─────────────────────────────────────────────────────────────────
# vortex:player/inv/offhand_item
# Runs a command/function for each player in @a whose offhand
# matches the given item id and custom data.
# Mirrors the pattern of vortex:player/inv/selected_item (mainhand).
#
# INPUT : $(item)       → item id (e.g. "minecraft:shield")
#         $(custom_data) → custom_data compound to match (e.g. "{my_tag:1b}")
#         $(invoke)     → command to run as the matching player
#
# EXAMPLE:
# function vortex:player/inv/offhand_item {item:"minecraft:shield",custom_data:"{my_tag:1b}",invoke:"function mypack:on_shield"}
# ─────────────────────────────────────────────────────────────────

$execute as @a[name=$(player),limit=1] at @s if items entity @s weapon.offhand $(item)[minecraft:custom_data=$(custom_data)] run $(invoke)
