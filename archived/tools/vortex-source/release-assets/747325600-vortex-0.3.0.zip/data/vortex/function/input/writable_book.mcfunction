# ======================================================================================
# vortex:input/writable_book
# ======================================================================================
#
# TRIGGERED BY: #vortex:input/writable_book function tag
# (also listed in #vortex:loop so it is scanned every tick)
#
# PURPOSE:
#   Detect a player holding a writable_book marked with
#   custom_data={vortex:{input:1b,inputItem:"writable_book"}} (given
#   via vortex:input/give/writable_book),
#   and extract the raw text of page[0] from
#   SelectedItem.components."minecraft:writable_book_content".pages[0].raw
#   into vortex:input storage. Input capture ONLY — no execution here.
#
# BOOK IS KEPT:
#   Capture does not clear/delete the book. One-shot per hold-session uses
#   tag vortex.book_captured; the tag is removed when the player is no
#   longer holding the marked book so a later re-select can submit again.
#
# WHY THIS ONLY CHECKS THE MAINHAND SELECTED ITEM:
#   'SelectedItem' reflects the player's currently held mainhand item at
#   entity-data-read time. If the marked book is not currently selected,
#   this tick simply finds nothing — this is intentional, not a bug.
# ======================================================================================

# Release debounce for anyone no longer holding the marked input book.
# inputItem:"writable_book" distinguishes this from other input:1b
# carriers (name_tag, anvil) that used to share the same bare flag and
# could cross-trigger each other's capture.
execute as @a[tag=vortex.book_captured] unless entity @s[nbt={SelectedItem:{components:{"minecraft:custom_data":{vortex:{input:1b,inputItem:"writable_book"}}}}}] run tag @s remove vortex.book_captured

# Fast exit — skip entirely if no player is holding the marked book
execute unless entity @a[nbt={SelectedItem:{components:{"minecraft:custom_data":{vortex:{input:1b,inputItem:"writable_book"}}}}}] run return 0

execute as @a[nbt={SelectedItem:{components:{"minecraft:custom_data":{vortex:{input:1b,inputItem:"writable_book"}}}}}] run function vortex:input/private/book_capture
