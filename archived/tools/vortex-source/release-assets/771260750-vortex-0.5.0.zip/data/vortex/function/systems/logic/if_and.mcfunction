# vortex:systems/logic/if_and [MACRO]
# Dispatches func only if BOTH a and b are non-zero (logical AND).
# Composes with the other logic/if_* functions and any score-producing
# api/systems function: store each side's 0/1 result on a score first,
# then feed both into this as $(a)/$(b).
#
# INPUT (macro):
#   $(a)    -> first operand score value (non-zero = true)
#   $(b)    -> second operand score value (non-zero = true)
#   $(func) -> function id to run via #vortex:internal/dispatch if a && b

execute if data storage vortex:engine modules{logic:0b} run return 0
$scoreboard players set $if_and_a vortex.tmp $(a)
$scoreboard players set $if_and_b vortex.tmp $(b)
$data modify storage vortex:engine _dispatch.func set value "$(func)"
execute unless score $if_and_a vortex.tmp matches 0 unless score $if_and_b vortex.tmp matches 0 run function #vortex:internal/dispatch
