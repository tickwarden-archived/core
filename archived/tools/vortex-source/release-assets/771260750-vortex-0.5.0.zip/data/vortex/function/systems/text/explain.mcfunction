# ─────────────────────────────────────────────────────────────────
# vortex:systems/text/explain
# Prints the NBT text-component rendering rules this module exists to
# enforce. Useful when debugging output that looks wrong.
# ─────────────────────────────────────────────────────────────────

execute if data storage vortex:engine modules{text:0b} run return 0
tellraw @s [{"text":"[VORTEX] ","color":"#00AAAA","bold":true},{"text":"━━━ NBT text components (26.1+) ━━━","color":"#555555"}]
tellraw @s [{"text":"  {storage,nbt}                    ","color":"gray"},{"text":"→  \"Example Text\"  (quotes kept)","color":"red"}]
tellraw @s [{"text":"  {storage,nbt,interpret:true}     ","color":"gray"},{"text":"→  Example Text    (parsed as a component)","color":"yellow"}]
tellraw @s [{"text":"  {storage,nbt,interpret:false,","color":"gray"}]
tellraw @s [{"text":"                     plain:true}   ","color":"gray"},{"text":"→  Example Text    (raw value, no colouring)","color":"green"}]
tellraw @s [{"text":"  Numbers and booleans need plain:true too, or 1b renders coloured.","color":"gray","italic":true}]
tellraw @s [{"text":"[VORTEX] ","color":"#00AAAA","bold":true},{"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"#555555"}]
