# vortex:world/region/fill_keep [MACRO]
$fill $(x1) $(y1) $(z1) $(x2) $(y2) $(z2) $(block) keep
