# vortex:systems/geo/in_region_unless [MACRO]
execute if data storage vortex:engine modules{geo:0b} run return 0
$execute as @a[name=$(player),limit=1] unless entity @s[x=$(x),y=$(y),z=$(z),dx=$(dx),dy=$(dy),dz=$(dz)] run $(invoke)
