# vortex:systems/string/header [MACRO]
execute if data storage vortex:engine modules{string:0b} run return 0
$tellraw $(target) [{"text":"◆── ","color":"$(color)"},{"text":"$(text)","color":"$(color)","bold":true},{"text":" ──◆","color":"$(color)"}]
